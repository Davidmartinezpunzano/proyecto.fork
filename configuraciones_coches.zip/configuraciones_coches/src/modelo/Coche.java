/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author 33407.joan23
 */
public class Coche {
    String nombre;
    String telefono;
    String total;
    String modelo2;
    String color2;
    String opcion2;

    public Coche() {
    }

    public Coche(String nombre, String telefono, String total, String modelo2, String color2, String opcion2) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.total = total;
        this.modelo2 = modelo2;
        this.color2 = color2;
        this.opcion2 = opcion2;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getModelo2() {
        return modelo2;
    }

    public void setModelo2(String modelo2) {
        this.modelo2 = modelo2;
    }

    public String getColor2() {
        return color2;
    }

    public void setColor2(String color2) {
        this.color2 = color2;
    }

    public String getOpcion2() {
        return opcion2;
    }

    public void setOpcion2(String opcion2) {
        this.opcion2 = opcion2;
    }

   

    
    
}
